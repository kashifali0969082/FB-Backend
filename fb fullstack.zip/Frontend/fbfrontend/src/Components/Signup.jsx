import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faQuestionCircle } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";
import MyVerticallyCenteredModal from './MyVerticallyCenteredModal';
import axios from 'axios';

const Signup = () => {
  const navigate = useNavigate();
  const [modalShow, setModalShow] = useState(false);
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    dob: {
      day: '',
      month: '',
      year: ''
    },
    gender: '',
  });
  const [response, setResponse] = useState(null);

  const dataSaving = (e) => {
    const { name, value } = e.target;
    if (name in formData.dob) {
      setFormData(prevState => ({
        ...prevState,
        dob: {
          ...prevState.dob,
          [name]: value
        }
      }));
    } else {
      setFormData(prevState => ({
        ...prevState,
        [name]: value
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const dob = `${formData.dob.year}-${formData.dob.month.padStart(2, '0')}-${formData.dob.day.padStart(2, '0')}`;
    const updatedFormData = { ...formData, dob };
    console.log('Submitting Form Data:', updatedFormData);
    SignUp(updatedFormData);
  };

  const SignUp = async (data) => {
    try {
      const res = await axios.post('http://localhost:8000/api/SignUp_view/', data);
      console.log('Response:', res.data);
      setResponse(res.data);
      setModalShow(true);
    } catch (err) {
      console.error('Error:', err);
    }
  };

  useEffect(() => {
    if (response) {
      console.log(response);
    }
  }, [response]);

  return (
    <div className="container-fluid min-vh-100 background">
      <div className="row">
        <div className="d-flex flex-column justify-content-center align-items-center min-vh-100">
          <div>
            <img className="img_sizer" src="facebook.svg" alt="" />
          </div>
          <div className="carding2 d-flex row justify-content-center align-items-center px-3">
            <h3 className="text-center">Create a new account</h3>
            <p className="text-center quick">It's quick and easy.</p>
            <hr />
            <div className="gapping d-flex justify-content-center">
              <input
                className="infields"
                type="text"
                onChange={dataSaving}
                name="first_name"
                value={formData.first_name}
                placeholder="First name"
              />
              <input
                className="infields"
                onChange={dataSaving}
                type="text"
                name="last_name"
                value={formData.last_name}
                placeholder="Surname"
              />
            </div>
            <input
              className="infields mt-2"
              onChange={dataSaving}
              name="email"
              type="email"
              placeholder="Email address"
              value={formData.email}
            />
            <input
              className="infields mt-2"
              type="password"
              placeholder="New Password"
              name="password"
              value={formData.password}
              onChange={dataSaving}
            />
            <div className="divver d-flex gap-1 align-items-center">
              <p className="dob mt-2">Date of birth</p>
              <FontAwesomeIcon className="mt-2" icon={faQuestionCircle} />
            </div>
            <div className="divver d-flex gap-1 mt-1 justify-content-between">
              <div className="wid">
                <select
                  name="day"
                  value={formData.dob.day}
                  onChange={dataSaving}
                  className="form-select"
                  aria-label="Default select example"
                >
                  <option value="">Date</option>
                  {[...Array(31)].map((_, i) => (
                    <option key={i + 1} value={i + 1}>{i + 1}</option>
                  ))}
                </select>
              </div>
              <div className="wid">
                <select
                  name="month"
                  value={formData.dob.month}
                  onChange={dataSaving}
                  className="form-select"
                  aria-label="Default select example"
                >
                  <option value="">Month</option>
                  {['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'].map((month, index) => (
                    <option key={index} value={month}>{month}</option>
                  ))}
                </select>
              </div>
              <div className="wid">
                <select
                  name="year"
                  value={formData.dob.year}
                  onChange={dataSaving}
                  className="form-select"
                  aria-label="Default select example"
                >
                  <option value="">Year</option>
                  {[...Array(15)].map((_, i) => (
                    <option key={2024 - i} value={2024 - i}>{2024 - i}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="divver d-flex gap-1 align-items-center">
              <p className="dob mt-2">Gender</p>
              <FontAwesomeIcon className="mt-2" icon={faQuestionCircle} />
            </div>
            <div className="divver gap-2 d-flex justify-content-between">
              <div className="wid px-1 py-2 bordering d-flex justify-content-between">
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Female
                </label>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    value="female"
                    checked={formData.gender === 'female'}
                    type="radio"
                    name="gender"
                    onChange={dataSaving}
                    id="flexRadioDefault1"
                  />
                </div>
              </div>
              <div className="wid px-1 py-2 bordering d-flex justify-content-between">
                <label className="form-check-label" htmlFor="flexRadioDefault2">
                  Male
                </label>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    value="male"
                    checked={formData.gender === 'male'}
                    onChange={dataSaving}
                    type="radio"
                    name="gender"
                    id="flexRadioDefault2"
                  />
                </div>
              </div>
              <div className="wid px-1 py-2 bordering d-flex justify-content-between">
                <label className="form-check-label" htmlFor="flexRadioDefault3">
                  Custom
                </label>
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="gender"
                    value="custom"
                    checked={formData.gender === 'custom'}
                    onChange={dataSaving}
                    id="flexRadioDefault3"
                  />
                </div>
              </div>
            </div>
            <div className="divver">
              <p className="text mt-2">
                People who use our service may have uploaded your{" "}
                <span className="blueing">contact</span> information to
                Facebook. Learn more.
              </p>
              <p className="text">
                By clicking Sign Up, you agree to our Terms,{" "}
                <span className="blueing">Privacy</span> Policy and Cookies
                Policy. You may receive SMS{" "}
                <span className="blueing">notifications</span> from us and can
                opt out at any time.
              </p>
            </div>
            <button className="btn3 mt-2" onClick={handleSubmit}>
              Sign Up
            </button>
            <MyVerticallyCenteredModal
            email={formData.email}
              show={modalShow}
              onHide={() => setModalShow(false)}
            />
            <div>
              <span className="mt-2 d-flex justify-content-center">
                <a className="forgotetn" onClick={() => navigate('/')} href="#">
                  Already have an account???
                </a>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
