import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
const MyVerticallyCenteredModal = (props) => {
  const { email } = props;
  const [input, setInput] = useState('');

  const inputtake = (e) => {
    setInput(e.target.value);
    console.log('Current input value:', e.target.value); // Log the value as you type
  };
  
  const validation =async  (data) => {
    try {
      const res = await axios.post('http://localhost:8000/api/verification_view/', {
        'email':email,
        'verification_code':input,
      });
      console.log('Response:', res.data);
   
    } catch (err) {
      console.error('Error:', err);
    }
  };

  return (
    <Modal
      {...props}
      size="md"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header className="justify-content-center">
        <Modal.Title id="contained-modal-title-vcenter">
          Email Configuration
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>
          A number is sent to your Gmail account given above for privacy and safety reasons.
        </p>
        <input
          className="infields w-100"
          onChange={inputtake}
          placeholder="Enter the number sent on your Email"
          type="text"
        />
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={props.onHide}>Close</Button>
        <Button onClick={validation}>Confirm</Button>
      </Modal.Footer>
    </Modal>
  );
};

export default MyVerticallyCenteredModal;
