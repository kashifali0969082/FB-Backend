import React from 'react'

const Home = () => {
  return (
    <div>
      this is home
    </div>
  )
}

export default Home
