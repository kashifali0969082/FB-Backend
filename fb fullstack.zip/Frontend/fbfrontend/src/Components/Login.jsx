import React, { useState } from "react";
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate(); // Use navigate hook here

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const signupClick = () => {
    // Navigate to the "/Signup" route
    navigate('/Signup');
  };

  return (
    <div>
      <div className="container-fluid min-vh-100 background">
        <div className="row">
          <div className="adjuster2 col-6 d-flex justify-content-end align-items-center min-vh-100">
            <div className="midding">
              <img className="img_sizer" src="facebook.svg" alt="" />
              <h2 className="data">
                Facebook helps you connect and share with the people in your life.
              </h2>
            </div>
          </div>
          <div className="adjuster col-6 d-flex justify-content-start align-items-center">
            <div className="carding d-flex row justify-content-center align-items-center px-3">
              <input
                className="fields"
                type="text"
                placeholder="Email address or phone number"
              />
              <input
                className="fields"
                type={showPassword ? "text" : "password"}
                placeholder="Password"
              />
              <FontAwesomeIcon
                icon={showPassword ? faEyeSlash : faEye}
                onClick={togglePasswordVisibility}
                style={{
                  position: "relative",
                  right: "-160px",
                  top: "-37px",
                  transform: "translateY(-50%)",
                  cursor: "pointer",
                }}
              />
              <button className="btn">
                Log in
              </button>
             
              <span className="mt-2 d-flex justify-content-center">
                <a className="forgotetn" href="xxx.com">
                  Forgotten password?
                </a>
              </span>
              <hr className="mt-3" />
              <button className="btn2 mt-3" onClick={signupClick}>
                Create new account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
