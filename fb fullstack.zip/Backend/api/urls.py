from rest_framework.routers import DefaultRouter
from django.urls import path,include
from Authentication.views import SignUp_view,Login_view,verification_view
router = DefaultRouter()
urlpatterns = [
    
    path('',include(router.urls)),
path('SignUp_view/',SignUp_view),
path('verification_view/',verification_view),
path('Login_view/',Login_view)
]