from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin

class LoginRequiredMiddleware(MiddlewareMixin):
    def process_request(self, request):
        # Allow access to login and signup pages
        if not request.session.get('user_id') and request.path not in ['/Login_view', '/SignUp_view']:
            # Return a standard HTTP response with a message
            return HttpResponse('Login Required. Please log in.', status=401)
        return None  # Continue processing if not redirecting
