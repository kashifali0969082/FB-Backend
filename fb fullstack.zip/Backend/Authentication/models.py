from django.db import models

class Signup(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    password = models.CharField(max_length=50)  # Consider using Django's built-in user model for secure password handling
    dob = models.DateField()
    gender = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
