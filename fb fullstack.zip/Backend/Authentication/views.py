from django.shortcuts import render
from .models import Signup
from rest_framework.decorators import api_view
from .serializers import SignupSerializer,LoginSerializer
from rest_framework.response import Response
from rest_framework import status  
from django.core.mail import EmailMessage
import random

# In-memory storage for verification codes and pending signups
verification_codes = {}
pending_signups = {}

@api_view(['POST'])
def SignUp_view(request):
    if request.method == 'POST':
        data = request.data
        print("data---------------", data)
        
        serializer = SignupSerializer(data=data)
        if serializer.is_valid():
            email = serializer.validated_data.get('email')
            random_number = random.randint(0, 100)
            verification_codes[email] = random_number  # Store the code with the email
            
            # Store the serializer data temporarily for later use
            pending_signups[email] = serializer.validated_data
            
            print("kashif random number", random_number)
            # Send the email with the verification number
            ver = EmailMessage(
                'info',
                f'Enter the given number: {random_number} in the modal to sign up',
                'kashifali0969082@gmail.com',  # Replace with your sender email
                [email]
            )
            ver.send()

            return Response({'message': 'Sign-up successful, please verify your email.'}, status=status.HTTP_201_CREATED)
        
        return Response({'message': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
    
    return Response({'message': 'Method not allowed'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)


@api_view(['POST'])
def verification_view(request):
    if request.method == 'POST':
        email = request.data.get('email')
        verification_code = request.data.get('verification_code')

        if email and verification_code:
            if verification_codes.get(email) == int(verification_code):
                # Verification successful
                del verification_codes[email]  # Remove the code after successful verification

                # Retrieve and save the pending sign-up data
                signup_data = pending_signups.pop(email, None)
                if signup_data:
                    serializer = SignupSerializer(data=signup_data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response({'message': 'Verification successful and data saved'}, status=status.HTTP_200_OK)
                    else:
                        return Response({'message': 'Data is invalid'}, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response({'message': 'No pending sign-up found'}, status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({'message': 'Invalid verification code'}, status=status.HTTP_400_BAD_REQUEST)
        
        return Response({'message': 'Email and verification code are required'}, status=status.HTTP_400_BAD_REQUEST)
    
    return Response({'message': 'Method not allowed'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)





@api_view(['POST'])
def Login_view(request):
    if request.method=='POST':
        data=request.data
        print(data)
        serializer=LoginSerializer(data=data)
        if serializer.is_valid():
            user = serializer.validated_data['user']  
            request.session['user_id'] = user.id
            return Response("LOGED IN", status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)





# 3. Accessing and Using Session Data
# After setting session data, you can access it in any view to check if a user is logged in or to retrieve user-specific information.

# python
# Copy code
# def some_protected_view(request):
#     # Check if the user is logged in
#     if request.session.get('user_id'):
#         user_id = request.session['user_id']
#         username = request.session['username']
#         # Use the session data as needed
#         return render(request, 'protected_page.html', {'username': username})
#     else:
#         return redirect('login')