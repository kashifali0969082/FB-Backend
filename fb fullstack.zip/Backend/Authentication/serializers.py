from rest_framework import serializers
from .models import Signup
from django.contrib.auth import authenticate

class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model = Signup
        fields = '__all__'

    def validate(self, data):
        """
        Check that a user with the same first name, last name, and Gmail address does not exist.
        """
        first_name = data.get('first_name')
        last_name = data.get('last_name')
        email = data.get('email')

        # Check if a user with the same first name, last name, and Gmail address exists
        if Signup.objects.filter(first_name=first_name).exists():
            if  Signup.objects.filter(last_name=last_name).exists():
              raise serializers.ValidationError("A user with this name already exists.")



        if Signup.objects.filter(email=email).exists():
            raise serializers.ValidationError("A user with this email already exists.")
        # Additional check to ensure email contains '@gmail.com'
        if not email.endswith('@gmail.com'):
            raise serializers.ValidationError("Email must be a Gmail address.")
        
        # Check that first name and last name are not the same
        if first_name == last_name:
            raise serializers.ValidationError("First name and last name cannot be the same.")
        
        return data


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        email = data.get('email')
        password = data.get('password')

        try:
            user = Signup.objects.get(email=email)  # Get the Signup instance
        except Signup.DoesNotExist:
            raise serializers.ValidationError("No user found with this email.")

        if user.password != password:  # Direct comparison if passwords are stored as plain text
            raise serializers.ValidationError("Wrong password.")

        data['user'] = user
        return data

# class LoginSerializer(serializers.Serializer):
#     email = serializers.EmailField()
#     password = serializers.CharField(write_only=True)

#     def validate(self, data):
       
#        password=data.get('password')
#        email = data.get('email')
#        x=Signup.objects.filter(email=email)
#        if x.exists():
#             if  x.password!=password:
#               raise serializers.ValidationError("Wrong password.")

       
#        return data
